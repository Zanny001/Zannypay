import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../theme/colors';
import { formatCurrency, formatDate } from '../utils/format';

export default function TransactionRow({ txn }) {
  const isCredit = txn.type === 'credit';
  return (
    <View style={styles.row}>
      <View style={[styles.iconWrap, { backgroundColor: isCredit ? '#E7F8ED' : '#F3EEFD' }]}>
        <Ionicons
          name={isCredit ? 'arrow-down-circle' : 'arrow-up-circle'}
          size={22}
          color={isCredit ? colors.success : colors.primary}
        />
      </View>
      <View style={{ flex: 1 }}>
        <Text style={styles.title} numberOfLines={1}>{txn.title}</Text>
        {!!txn.subtitle && <Text style={styles.subtitle} numberOfLines={1}>{txn.subtitle}</Text>}
        <Text style={styles.date}>{formatDate(txn.date)}</Text>
      </View>
      <Text style={[styles.amount, { color: isCredit ? colors.success : colors.textDark }]}>
        {isCredit ? '+' : '-'}{formatCurrency(txn.amount)}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  iconWrap: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  title: { fontSize: 15, fontWeight: '600', color: colors.textDark },
  subtitle: { fontSize: 12, color: colors.textMuted, marginTop: 2 },
  date: { fontSize: 11, color: colors.textMuted, marginTop: 2 },
  amount: { fontSize: 15, fontWeight: '700', marginLeft: 8 },
});
